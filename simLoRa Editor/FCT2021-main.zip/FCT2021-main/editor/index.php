<!DOCTYPE html>
<html>
<meta charset="utf-8">

<link rel="stylesheet" type="text/css" href="lib/css/styles.css">
<head>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <script src="https://unpkg.com/@google/markerclustererplus@4.0.1/dist/markerclustererplus.min.js"></script>
	<script src="lib/js/map.js"></script>
	<?php 
	require_once 'vendor/autoload.php';


try{
	$client = new MongoDB\Client('mongodb://www:wwwp@localhost');


	$collection = $client->editor->data;
	$cursor = $collection->find();

	foreach ($cursor as $doc) {
		var_dump($doc);
		echo("<input id=".$doc['_id']." hidden </input>");
	    echo($doc['NAME']."<br>");
	    echo($doc['LATITUDE']."<br>");
	    echo($doc['LONGITUDE']."<br>d<br>");
	}
}catch(Exception $e){
	var_dump($e->getMessage(),"<br>");
}
?>
	<title>Lagoa Do Algarve</title>
</head>
<body>
	<div id="map" >	</div>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAbu6pI0vXCQCxObq8jdHEIv2ueYV-rbiY&callback=initMap&libraries=&v=weekly"
      async ></script>
</body>

<span id="<?php /*echo($doc['_id'].'<br>'); */?>1"></span>
<?php /*$somearray = array(
	"lat" => $doc['LATITUDE'],
	"lng" => $doc['LONGITUDE'],
);
	echo $somearray;
-*/
 ?>

</html>